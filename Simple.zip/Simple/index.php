<?php
$connect = new PDO("mysql:host=localhost;dbname=asurecord", "root", "");
?>
<table border="1">
    <thead>
        <th>Name</th>
        <th>User Name</th>
        <th>Email</th>
    </thead>
    <tbody>
        <?php
        $signup = $connect->query("SELECT * FROM signup");
        while ($signupData = $signup->fetch()) {
        ?>
            <tr>
                <td><?php echo $signupData['name']; ?></td>
                <td><?php echo $signupData['username']; ?></td>
                <td><?php echo $signupData['email']; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>